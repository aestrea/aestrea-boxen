## Popcorn-Time
See https://popcorntime.io/

[![Build Status](https://travis-ci.org/josanastrid/puppet-popcorntime.svg?branch=0.3.2)](https://travis-ci.org/josanastrid/puppet-popcorntime)

## Usage

```puppet
include popcorntime
```
