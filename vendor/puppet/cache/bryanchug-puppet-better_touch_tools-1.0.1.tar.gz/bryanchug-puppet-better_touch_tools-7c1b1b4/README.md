# BetterTouchTool Puppet Module for Boxen

Install [BetterTouchTool](http://bettertouchtool.net/), a way of customising gestures on your Mac.

## Usage

```puppet
include better_touch_tools
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script` directory for other useful tools.
