## Popcorn-Time
See https://popcorntime.io/

[![Build Status](https://travis-ci.org/josanastrid/puppet-popcorntime.svg?branch=1.0.0)](https://travis-ci.org/josanastrid/puppet-popcorntime)

## Usage

```puppet
include popcorntime
```
